# This file should contain all the record creation needed to seed the database with its default values.
# The data can then be loaded with the rails db:seed command (or created alongside the database with db:setup).
#
# Examples:
#
#   movies = Movie.create([{ name: 'Star Wars' }, { name: 'Lord of the Rings' }])
#   Character.create(name: 'Luke', movie: movies.first)

todo1 = Todo.create(title: 'Go on vacation', body: 'Scandinavia or Europe or back to Japan or to Thailand or Amsterdam', done: false)

todo2 = Todo.create(title: 'Study', body: 'Study React and Redux', done: false)

todo3 = Todo.create(title: 'Say Help Me', body: 'Heeelppp', done: true)

todo4 = Todo.create(title: 'Get Carried', body: 'Get carried by Jeremiah', done: true)
