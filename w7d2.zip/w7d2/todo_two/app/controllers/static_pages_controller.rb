class StaticPagesController < ApplicationController

  def root
  end
end
