class User < ApplicationRecord
  validates :username, :password_digest, :session_token

  validates :password, length: {minimum: 6, allow_nil: true}

  attr_reader :password

  has_many :subreddits

end
