class Sub < ApplicationRecord

  validates :title, :description, :moderator_id, presence: true

  belongs_to :user
  belongs_to :moderator
  has_many :posts
end
