const View = require ("./ttt-view.js")
const Game = require ("../../node_solution/board.js")

$( () => {
  const game = new Game

  const grid = $('.ttt');

  const view = new View(game, grid);

  // View.prototype.setupBoard = function(){
  //   let unorderedList = $(<ul></ul>);
  //   unorderedList.addClass("unordered-list");
  //   let newLi = $(<li></li>);
  //   newLi.addClass("square");
  //   unorderedList.append(newLi);
  // }
  //
  // setupBoard();

});
