class View {
  constructor(game, $el) {
    this.game = game;
    this.$el = $el;

    this.setupBoard();
    this.bindEvents();
  }

  bindEvents() {
    // event.preventDefault();
    // const $cells = $("li");
    //
    // $cells.click(makeMove);

    const $list = $("ul");
    const $cell = $("li");

    this.$el.on("click", "li", (e => {
      const $square = $(e.currentTarget);
      //the e accesses the click event
      this.makeMove($square)}));
  }




  makeMove($square) {
    // $square.text("X")
    $square.css("background-color", "SkyBlue");
    $square.text("X")
  }



  setupBoard() {
    const $unorderedList = $("<ul>");
    // $unorderedList.addClass("unordered-list");

    // for(let = 1; i <= 9; i++){
    for (let rowIdx = 0; rowIdx < 3; rowIdx++) {
      for (let colIdx = 0; colIdx < 3; colIdx++) {
        let $cell = $("<li>");
        $cell.data("pos", rowIdx, colIdx);
        // newLi.addClass("square");
        $unorderedList.append($cell);
      }
    }
    this.$el.append($unorderedList);
  }
}

module.exports = View;
