const followToggle = require ('./follow_toggle.js');

$(() =>{
  const buttonToggles = $('button.follow-toggles');

  buttonToggles.each( constructor());
});
