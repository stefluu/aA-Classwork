export const RECEIVE_TODOS = 'RECEIVE_TODOS';

export const RECEIVE_TODO = 'RECIEVE_TODO';

export const recieveTodos = todos => {
  return {
    type: RECEIVE_TODOS,
    todos
  };
};

export const receiveTodo = todo => {
  return {
    type: RECEIVE_TODO,
    todo
  };
};
