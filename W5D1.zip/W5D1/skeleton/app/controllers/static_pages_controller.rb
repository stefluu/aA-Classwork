class StaticPagesController < ApplicationController
	def index
	end
end
