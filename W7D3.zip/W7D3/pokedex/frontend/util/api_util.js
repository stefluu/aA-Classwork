const fetchAllPokemon = function() {
  return $.ajax({
    method: 'GET',
    url: 'api/pokemon'
  });
};

export default fetchAllPokemon;

//root -> ruut or rut
//route -> rowt or ruut
