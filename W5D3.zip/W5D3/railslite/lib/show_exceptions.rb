require 'erb'

class ShowExceptions
  def initialize(app)
  end

  def call(env)
  end

  private

  def render_exception(e)
  end

end
